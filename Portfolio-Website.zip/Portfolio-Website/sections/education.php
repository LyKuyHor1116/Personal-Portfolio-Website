<section id="education" class="education">
  <h2 class="section-title">Education</h2>

  <div class="box-container reveal">
    <?php
    $educations = [
      [
        "image" => "assets/images/uc-image.png",
        "school" => "The University of Cambodia",
        "degree" => "Bachelor's Degree of IT",
        "year" => "2023 – Present"
      ],
    ];

    foreach ($educations as $edu):
    ?>
      <div class="box">

        <div class="image">
          <img src="<?= $edu['image'] ?>" alt="<?= $edu['school'] ?>" onclick="openImage(this.src)">
        </div>

        <!-- Content -->
        <div class="content">
          <h3><?= $edu['school'] ?></h3>
          <h4><?= $edu['degree'] ?></h4>
          <p><?= $edu['year'] ?></p>
        </div>

      </div>
    <?php endforeach; ?>
  </div>
</section>
