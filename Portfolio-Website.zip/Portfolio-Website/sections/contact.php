<section id="contact" class="section">
    <h2 class="section-title">Contact</h2>


    <?php if (isset($_GET['success'])): ?>
        <p class="success-msg">Message sent successfully ✅</p>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
        <p class="error-msg">Something went wrong ❌</p>
    <?php endif; ?>

    <div class="contact-wrapper reveal delay-1">
        <div class="contact-info-box">
            <h3>Get in Touch</h3>
            <p>If you’d like to work together or have any questions, feel free to contact me.</p>
            <div class="contact-item">
                <i class="fas fa-envelope"></i>
                <span>lykuyhor@gmail.com</span>
            </div>
            <div class="contact-item">
                <i class="fas fa-phone"></i>
                <span>+855 12 345 678</span>
            </div>
            <div class="contact-item">
                <i class="fas fa-location-dot"></i>
                <span>Phnom Penh, Cambodia</span>
            </div>

            <div class="contact-socials">
                <a href="#"><i class="fab fa-github"></i></a>
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-telegram"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>

        <form class="contact-form"
            action="save_contact.php"
            method="POST">
            <input type="text" placeholder="Your Name" name="name" required>
            <input type="email" placeholder="Email Address" name="email" required>
            <textarea rows="5" placeholder="Your Message" name="message" required></textarea>
            <button type="submit" class="btn btn-primary">
                Send Message
            </button>

        </form>
    </div>

</section>
