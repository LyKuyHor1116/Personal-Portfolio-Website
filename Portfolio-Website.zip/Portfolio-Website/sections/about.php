<section id="about" class="section">
    <h2 class="section-title">About Me</h2>

    <div class="about-grid reveal">

        <!-- IMAGE WITH SQUARE LINE -->
        <div class="about-img">
            <div class="img-box">
                <img src="assets/images/profile(2).png" alt="About">
            </div>
        </div>

        <!-- INFO CARDS -->
        <div class="about-cards">

            <div class="about-card">
                <i class="fas fa-id-card"></i>
                <h4>Personal Background</h4>
                <p>IT Student</p>
            </div>

            <div class="about-card">
                <i class="fas fa-flag-checkered"></i>
                <h4>Career Objective</h4>
                <p> Web Developer</p>
            </div>

            <div class="about-card">
                <i class="fas fa-palette"></i>
                <h4>Interests & Hobbies</h4>
                <p>Reading • Researching • Coding</p>
            </div>

            <div class="about-card">
                <i class="fas fa-pen-nib"></i>
                <h4>Short Biography</h4>
                <p>Passionate about creating PHP Websites.</p>
            </div>

        </div>
    </div>
</section>