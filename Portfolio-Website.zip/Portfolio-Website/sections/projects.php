<section class="section reveal" id="projects">
    <h2 class="section-title">Projects</h2>

    <div class="projects-grid">

        <!-- PROJECT 1 -->
        <div class="project-card reveal">
            <div class="project-image">
                <img src="assets/images/student-management-system.png" alt="Project">
            </div>

            <h3>Student Management System</h3>

            <p>
                Web-based system for managing students, courses,
                enrollments, and payments.
            </p>

            <div class="project-tech">
                <span>PHP</span>
                <span>MySQL</span>
                <span>Bootstrap</span>
            </div>

            <div class="project-buttons">
                <a href="https://github.com/LyKuyHor1116/Student-Management-System"
                    target="_blank"
                    class="btn-outline">
                    View Code
                </a>

                <button class="btn-primary"
                    onclick="openImage('assets/images/student-management-system.png')">
                    View Image
                </button>
            </div>
        </div>

        <!-- PROJECT 2 -->
        <div class="project-card reveal">
            <div class="project-image">
                <img src="assets/images/coffee-management-system.png" alt="Project">
            </div>

            <h3>Coffee Shop Management System</h3>

            <p>
                Web-based system for managing coffee shop operations,
                including menu, orders, inventory, and staff.
            </p>

            <div class="project-tech">
                <span>PHP</span>
                <span>MySQL</span>
                <span>Bootstrap</span>
            </div>

            <div class="project-buttons">
                <a href="https://github.com/LyKuyHor1116/Coffee-Shop-System"
                    target="_blank"
                    class="btn-outline">
                    View Code
                </a>

                <button class="btn-primary"
                    onclick="openImage('assets/images/coffee-management-system.png')">
                    View Image
                </button>
            </div>
        </div>

    </div>
</section>