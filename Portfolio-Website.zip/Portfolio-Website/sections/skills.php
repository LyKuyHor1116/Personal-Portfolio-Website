<section id="skills" class="section">
    <h2 class="section-title">Skills</h2>

    <!-- ================= TECHNICAL SKILLS ================= -->
    <h3 class="skills-subtitle">Technical Skills</h3>

    <div class="skills-grid reveal">
        <?php
        $technicalSkills = [
            ["HTML", 90, "Advanced", "fab fa-html5"],
            ["CSS", 85, "Advanced", "fab fa-css3-alt"],
            ["JavaScript", 78, "Intermediate", "fab fa-js"],
            ["PHP", 95, "Advanced", "fab fa-php"],
            ["Laravel", 90, "Advanced", "fab fa-laravel"],
            ["Java", 80, "Intermediate", "fab fa-java"],
            ["Python", 83, "Intermediate", "fab fa-python"],
            ["MySQL", 91, "Advanced", "fas fa-database"],
        ];

        foreach ($technicalSkills as $skill):
        ?>
            <div class="skill-card">

                <div class="skill-header">
                    <i class="<?= $skill[3] ?>"></i>
                    <div>
                        <h4><?= $skill[0] ?></h4>
                        <span class="level <?= strtolower($skill[2]) ?>">
                            <?= $skill[2] ?>
                        </span>
                    </div>
                </div>

                <!-- PROGRESS BAR + REAL % -->
                <div class="progress">
                    <div class="progress-bar" data-width="<?= $skill[1] ?>%">
                        <span><?= $skill[1] ?>%</span>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

    <!-- ================= SOFT SKILLS ================= -->
    <h3 class="skills-subtitle">Soft Skills</h3>

    <div class="skills-grid reveal">
        <?php
        $softSkills = [
            ["Communication", "Advanced", "fas fa-comments"],
            ["Teamwork", "Advanced", "fas fa-users"],
            ["Problem Solving", "Advanced", "fas fa-lightbulb"],
            ["Time Management", "Intermediate", "fas fa-clock"],
            ["Adaptability", "Intermediate", "fas fa-sync-alt"],
        ];

        foreach ($softSkills as $skill):
        ?>
            <div class="skill-card soft">

                <div class="skill-header">
                    <i class="<?= $skill[2] ?>"></i>
                    <div>
                        <h4><?= $skill[0] ?></h4>
                        <span class="level <?= strtolower($skill[1]) ?>">
                            <?= $skill[1] ?>
                        </span>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>
</section>