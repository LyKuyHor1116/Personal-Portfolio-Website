<section id="home" class="section home">
    <div class="home-content reveal">
        <div class="home-text">
            <p class="welcome">Welcome to my portfolio!</p>
            <h1>I'm <span>Ly KuyHor</span></h1>
            <p class="intro">I enjoy coding and building modern, responsive web applications by using PHP and Laravel.</p>
            <a href="#about" class="btn-scroll">Discover More</a>
        </div>
        <div class="home-img">
            <img src="assets/images/profile.png" alt="Ly KuyHor">
        </div>
    </div>
</section>
