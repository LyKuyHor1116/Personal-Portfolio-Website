<footer>
    © 2026 • Designed with 💖 by Ly KuyHor
</footer>

<script src="assets/js/particles.min.js"></script>
<script src="assets/js/script.js"></script>
</body>

</html>