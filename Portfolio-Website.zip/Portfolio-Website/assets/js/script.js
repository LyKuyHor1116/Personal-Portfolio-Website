document.addEventListener('DOMContentLoaded', () => {

  /* =========================
     SCROLL REVEAL
  ========================= */
  const reveals = document.querySelectorAll('.reveal');

  function revealOnScroll() {
    reveals.forEach(el => {
      const top = el.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;

      if (top < windowHeight - 100) {
        el.classList.add('active');
      }
    });
  }

  window.addEventListener('scroll', revealOnScroll);
  revealOnScroll();

  /* =========================
     SKILL PROGRESS
  ========================= */
  const bars = document.querySelectorAll('.progress-bar');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.width =
          entry.target.getAttribute('data-width');
      }
    });
  }, { threshold: 0.4 });

  bars.forEach(bar => observer.observe(bar));

  /* =========================
     DARK / LIGHT MODE
  ========================= */
  const toggle = document.getElementById('themeToggle');

  if (toggle) {
    if (localStorage.getItem('theme') === 'light') {
      document.body.classList.add('light');
      toggle.innerHTML = '<i class="fas fa-sun"></i>';
    }

    toggle.addEventListener('click', () => {
      document.body.classList.toggle('light');

      const isLight = document.body.classList.contains('light');
      toggle.innerHTML = isLight
        ? '<i class="fas fa-sun"></i>'
        : '<i class="fas fa-moon"></i>';

      localStorage.setItem('theme', isLight ? 'light' : 'dark');
    });
  }

});

/* =========================
   IMAGE MODAL
========================= */
function openImage(src) {
  const modal = document.createElement('div');
  modal.className = 'image-modal';
  modal.innerHTML = `<img src="${src}" alt="Preview">`;
  modal.onclick = () => modal.remove();
  document.body.appendChild(modal);
}
