<?php include 'includes/header.php'; ?>

<?php include 'sections/home.php'; ?>
<?php include 'sections/about.php'; ?>
<?php include 'sections/skills.php'; ?>
<?php include 'sections/education.php'; ?>
<?php include 'sections/projects.php'; ?>
<?php include 'sections/contact.php'; ?>

<?php include 'includes/footer.php'; ?>
